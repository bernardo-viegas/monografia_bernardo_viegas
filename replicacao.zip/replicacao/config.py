"""
Parâmetros comuns a todos os scripts da replicação.

Os arquivos de dados ficam na pasta indicada por DADOS. Por padrão, é a subpasta
"dados" desta pasta; para usar outra, defina a variável de ambiente TCC_DADOS.
Os resultados (arquivos .json) vão para "resultados" e as figuras, para "figuras".
"""
import os
from pathlib import Path

import duckdb

PASTA = Path(__file__).resolve().parent
DADOS = Path(os.environ.get("TCC_DADOS", PASTA / "dados"))
RESULTADOS = PASTA / "resultados"
FIGURAS = PASTA / "figuras"
RESULTADOS.mkdir(exist_ok=True)
FIGURAS.mkdir(exist_ok=True)

# --- arquivos de dados
PASTA_BRUTA = DADOS / "hvfhv_mensal"                     # arquivos mensais da TLC, só com as colunas usadas
PAINEL = DADOS / "painel_regressao_uber_lyft.parquet"     # viagens da Uber usadas nas regressões
COMPETICAO = DADOS / "competicao_mensal.csv"              # Competição_t: participação mensal da Lyft
EXPOSICAO = DADOS / "exposicao_zona.csv"                  # Exposição_z: participação da Lyft por zona em 2021
METADADOS = DADOS / "metadados_painel.json"               # cortes de valores extremos e contagens
ZONAS = DADOS / "taxi_zone_lookup.csv"                    # zonas da TLC e seus boroughs (site da TLC)
EXPOSICAO_TAXI = DADOS / "exposicao_taxi_zona.csv"        # participação do táxi por zona em 2021

# --- recorte temporal
ANOS = [2021, 2022, 2023, 2024]
BASE_INICIO, BASE_FIM = "2021-01-01", "2022-01-01"        # período-base da exposição (fim exclusivo)
AMOSTRA_INICIO, AMOSTRA_FIM = "2022-01-01", "2025-01-01"  # amostra; termina antes do pedágio urbano (05/01/2025)

# --- identificação das empresas na base da TLC
UBER, LYFT = "HV0003", "HV0005"

# --- especificação principal: efeitos fixos e variável dependente
EFEITOS_FIXOS = ["zona", "mes", "hora", "dia_semana"]
Y = "log_price_per_mile"


def conectar(memoria="6GB"):
    """Abre uma conexão DuckDB com limite de memória e sem barra de progresso."""
    con = duckdb.connect()
    con.execute(f"SET memory_limit='{memoria}'; SET preserve_insertion_order=false; SET enable_progress_bar=false;")
    return con
