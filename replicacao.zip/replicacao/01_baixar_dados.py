"""
Passo 1 — Baixa os registros de viagens de aplicativo da TLC (2021 a 2024).

Fonte: NYC Taxi and Limousine Commission, High Volume For-Hire Vehicle Trip Records
(https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page), um arquivo Parquet por mês.

Cada arquivo mensal tem cerca de 0,5 GB. Para economizar espaço, o script baixa um
arquivo por vez, guarda só as colunas usadas no trabalho e apaga o original.
Arquivos já extraídos são pulados, então o script pode ser interrompido e retomado.
"""
import time

import requests

from config import ANOS, PASTA_BRUTA, conectar

URL = "https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_{ano}-{mes:02d}.parquet"

# hvfhs_license_num: empresa (HV0003 = Uber, HV0005 = Lyft); pickup_datetime: início da viagem;
# PULocationID: zona de embarque; trip_miles: distância; trip_time: duração (segundos);
# base_passenger_fare: tarifa-base, sem pedágios, taxas, impostos e gorjetas.
COLUNAS = "hvfhs_license_num, pickup_datetime, PULocationID, trip_miles, trip_time, base_passenger_fare"


def baixar(url, destino):
    """Baixa o arquivo numa única requisição. Se o servidor recusar (ele limita downloads
    em sequência com HTTP 403), espera cada vez mais antes de tentar de novo."""
    for espera in [5, 60, 300, 600, 600, None]:
        try:
            with requests.get(url, stream=True, timeout=120) as r:
                r.raise_for_status()
                with open(destino, "wb") as f:
                    for bloco in r.iter_content(chunk_size=8 * 1024 * 1024):
                        f.write(bloco)
            return
        except requests.RequestException as erro:
            if espera is None:
                raise
            print(f"  falha ({erro}); nova tentativa em {espera} s", flush=True)
            time.sleep(espera)


PASTA_BRUTA.mkdir(parents=True, exist_ok=True)
con = conectar("2GB")
for ano in ANOS:
    for mes in range(1, 13):
        url = URL.format(ano=ano, mes=mes)
        destino = PASTA_BRUTA / url.split("/")[-1]
        if destino.exists():
            continue
        print(f"baixando {destino.name}", flush=True)
        completo = destino.with_suffix(".completo")
        baixar(url, completo)
        con.execute(f"COPY (SELECT {COLUNAS} FROM read_parquet('{completo}')) "
                    f"TO '{destino}' (FORMAT PARQUET, COMPRESSION ZSTD)")
        completo.unlink()
print("Concluído:", PASTA_BRUTA)
