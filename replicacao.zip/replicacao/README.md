# Replicação: competição e preços no transporte por aplicativo em Nova York

Código para reproduzir as estimações econométricas da monografia, a partir dos registros
públicos de viagens da NYC Taxi and Limousine Commission (TLC).

## Requisitos

- Python 3.9 ou mais recente
- Pacotes: `pip install duckdb numpy pandas matplotlib requests`
- Cerca de 35 GB livres em disco: 20 GB para os arquivos mensais (só com as colunas usadas)
  e 11 GB para o painel de regressão
- Memória: 8 GB são suficientes (o DuckDB processa a base em disco)

## Organização

| Arquivo | O que faz | Saída |
|---|---|---|
| `config.py` | Caminhos, período da amostra e especificação principal | — |
| `estimador.py` | Mínimos quadrados com efeitos fixos de alta dimensão, erros-padrão clusterizados (uma e duas vias) e distribuição t | — |
| `01_baixar_dados.py` | Baixa os registros de 2021 a 2024 (48 arquivos mensais) | `dados/hvfhv_mensal/` |
| `02_montar_painel.py` | Calcula Competição_t e Exposição_z e monta o painel de viagens da Uber (2022-2024) | `dados/painel_regressao_uber_lyft.parquet` e auxiliares |
| `03_estatisticas_descritivas.py` | Tabela 2 | `resultados/tabela2_descritivas.json` |
| `04_resultados_principais.py` | Tabela 3, colunas (1) a (6) | `resultados/tabela3.json` |
| `05_tendencias_paralelas.py` | Figura 8 e teste da tendência nos coeficientes mensais | `resultados/figura8.json`, `figuras/` |
| `06_robustez.py` | Tabelas 4 (colunas 2 a 4), 5, 7, 8 e 9 | `resultados/robustez.json` |
| `07_robustez_dados_brutos.py` | Tabela 4, coluna (5), e Tabela 6 | `resultados/robustez_dados_brutos.json` |
| `08_taxi.py` | Teste com o reajuste da tarifa do táxi e Figura 9 | `resultados/taxi.json`, `figuras/` |

## Como rodar

Os scripts devem ser executados nesta ordem, a partir desta pasta:

```
python 01_baixar_dados.py
python 02_montar_painel.py
python 03_estatisticas_descritivas.py
python 04_resultados_principais.py
python 05_tendencias_paralelas.py
python 06_robustez.py
python 07_robustez_dados_brutos.py
python 08_taxi.py
```

Os dados ficam na subpasta `dados`. Para usar outra pasta, defina a variável de ambiente
`TCC_DADOS`. O arquivo `taxi_zone_lookup.csv` (zonas da TLC e seus boroughs) deve ser
baixado do site da TLC e colocado na pasta de dados.

O passo 1 leva algumas horas, porque o servidor da TLC limita downloads em sequência.
Cada estimação sobre o painel completo leva de 1 a 3 minutos.

## Notas

- **Estimador.** Os regressores de interesse são constantes dentro de cada combinação de
  zona, mês, hora e dia da semana. Isso permite obter exatamente os mesmos coeficientes de
  uma regressão com variáveis binárias para cada efeito fixo a partir de somas por célula,
  sem carregar a base viagem a viagem na memória. Os detalhes estão em `estimador.py`.
- **Erros-padrão.** Clusterizados por zona (261 clusters), com o ajuste usual para amostras
  pequenas. Em duas vias, seguem Cameron, Gelbach e Miller (2011); se a variância resultar
  negativa, usa-se o maior dos erros-padrão de uma via. Os p-valores usam a distribuição t
  com o número de clusters menos um como graus de liberdade.
- **Percentis.** O corte de valores extremos usa percentis aproximados do DuckDB
  (`approx_quantile`), registrados em `metadados_painel.json`.
