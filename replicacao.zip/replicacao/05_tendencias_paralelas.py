"""
Passo 5 — Diagnóstico de tendências paralelas (Figura 8, Seção 4.3).

Estima, com os mesmos efeitos fixos e controles da equação (1), a diferença de preço
por milha entre zonas mais e menos expostas à Lyft em cada mês: coeficientes de
Exposição_z padronizada × 1[mês = m], com referência em janeiro de 2022.
Se a hipótese de tendências paralelas valesse, essa diferença acompanharia a
participação da Lyft, sem trajetória própria.

Teste nos coeficientes: regressão dos 36 coeficientes mensais na participação da Lyft
(em pontos percentuais) e numa tendência linear (em anos). Os p-valores dessa regressão
são aproximados, porque os coeficientes são estimados e correlacionados entre si.
(O teste direto no modelo, Exposição_z × tempo, é a coluna 2 da Tabela 3.)

Saídas: resultados/figura8.json e figuras/fig_tendencias_paralelas.png
"""
import json
from datetime import datetime

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np

from config import COMPETICAO, FIGURAS, PAINEL, RESULTADOS, conectar
from estimador import erros_padrao, erros_padrao_2vias, estimar, t_critico

con = conectar()

# Exposição padronizada (média 0, desvio-padrão 1 entre as viagens do painel).
media, dp = con.execute(f"SELECT avg(exposicao_z), stddev_samp(exposicao_z) FROM read_parquet('{PAINEL}')").fetchone()
con.execute(f"CREATE VIEW p AS SELECT *, (exposicao_z - {media}) / {dp} AS ez FROM read_parquet('{PAINEL}')")

# Um regressor por mês (exceto o de referência): exposição padronizada × 1[mês = m].
meses = [m for (m,) in con.execute("SELECT DISTINCT strftime(mes, '%Y-%m') FROM p ORDER BY 1").fetchall()]
REFERENCIA = meses[0]
regs = {m: f"ez * CAST(mes = DATE '{m}-01' AS INTEGER)" for m in meses[1:]}
res = estimar(con, "p", regs)
ep_zona, g_zona = erros_padrao(res)
ep_2vias, _ = erros_padrao_2vias(res)

comp = dict(con.execute(f"SELECT strftime(mes::DATE, '%Y-%m'), competicao_t FROM read_csv_auto('{COMPETICAO}')").fetchall())
serie = [{"mes": m, "beta": res["beta"].get(m, 0.0), "ep_zona": ep_zona.get(m, 0.0),
          "ep_2vias": ep_2vias.get(m, 0.0), "competicao": comp[m]} for m in meses]

# Regressão dos coeficientes mensais na participação da Lyft e numa tendência linear.
y = np.array([s["beta"] for s in serie])
X = np.column_stack([np.ones(len(y)), [100 * s["competicao"] for s in serie], np.arange(len(y)) / 12])
b = np.linalg.lstsq(X, y, rcond=None)[0]
e = y - X @ b
ep = np.sqrt(np.diag(e @ e / (len(y) - 3) * np.linalg.inv(X.T @ X)))
teste = {"por_pp_de_competicao": b[1], "ep_competicao": ep[1],
         "tendencia_por_ano": b[2], "ep_tendencia": ep[2],
         "r2": 1 - (e @ e) / ((y - y.mean()) @ (y - y.mean()))}
print("tendência própria das zonas expostas: "
      f"{100 * b[2]:.2f} p.p. por ano por desvio-padrão de exposição (ep {100 * ep[2]:.2f})")

(RESULTADOS / "figura8.json").write_text(json.dumps(
    {"exposicao_media": media, "exposicao_dp": dp, "referencia": REFERENCIA,
     "serie": serie, "teste_coeficientes": teste}, indent=2, default=float), encoding="utf-8")

# Figura: painel superior com os coeficientes (em % do preço por milha) e intervalo de
# confiança de 95% com erros-padrão clusterizados por zona; painel inferior com Competição_t.
t95 = t_critico(g_zona - 1)
x = [datetime.strptime(s["mes"], "%Y-%m") for s in serie]
beta = 100 * np.array([s["beta"] for s in serie])
erro = 100 * np.array([s["ep_zona"] for s in serie])
plt.rcParams.update({"font.family": "serif", "font.size": 10, "axes.grid": True, "grid.color": "#dddddd"})
fig, (a1, a2) = plt.subplots(2, 1, figsize=(6.3, 5.0), sharex=True, gridspec_kw={"height_ratios": [3, 2]})
a1.axhline(0, color="#444444", linewidth=0.8)
a1.fill_between(x, beta - t95 * erro, beta + t95 * erro, color="#2a78d6", alpha=0.18, linewidth=0,
                label="IC 95% (EP clusterizado por zona)")
a1.plot(x, beta, color="#2a78d6", marker="o", markersize=3, linewidth=1.3, label="Diferença estimada")
a1.set_ylabel("Diferença de preço por milha (%)\npor +1 desvio-padrão de exposição")
a1.legend(frameon=False, fontsize=8, loc="upper left")
a2.plot(x, [100 * s["competicao"] for s in serie], color="#c1541f", marker="s", markersize=3, linewidth=1.3)
a2.set_ylabel("Participação\nda Lyft (%)")
a2.xaxis.set_major_locator(mdates.MonthLocator(bymonth=(1, 7)))
a2.xaxis.set_major_formatter(mdates.DateFormatter("%m/%Y"))
for a in (a1, a2):
    a.spines[["top", "right"]].set_visible(False)
    for ano in (2023, 2024):                                  # linhas de virada de ano
        a.axvline(datetime(ano, 1, 1), color="#999999", linewidth=0.6, linestyle=":")
fig.tight_layout()
fig.savefig(FIGURAS / "fig_tendencias_paralelas.png", dpi=300, bbox_inches="tight")
