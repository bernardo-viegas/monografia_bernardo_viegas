"""
Passo 8 — Reajuste da tarifa do táxi como fonte alternativa de variação na competição
(Seção 5.2 e Figura 9).

Em 19/12/2022, a TLC reajustou a tarifa do táxi. Ao encarecer o táxi, o reajuste reduziu
a pressão competitiva sobre a Uber, mais nas zonas em que o táxi era mais presente.
Diferentemente da participação da Lyft, essa variação não responde aos preços da Uber.

Exposição ao táxi (exposicao_taxi_zona.csv): participação do táxi (amarelo e verde) no
total de viagens de táxi, Uber e Lyft iniciadas em cada zona em 2021. Se o arquivo não
existir, é calculado a partir dos registros de táxi de 2021 da TLC (24 arquivos mensais,
baixados um a um e apagados depois da contagem).

Especificações (efeitos fixos de zona, mês, hora e dia da semana; controles de viagem):
  (A) diferenças em diferenças: ExpTáxi_z × 1[mês ≥ jan/2023], com ExpTáxi_z × 1[dez/2022]
      à parte, porque o reajuste entrou em vigor no meio de dezembro;
  (B) (A) + a interação da Lyft (Exposição_z × Competição_t) como controle;
  (C) (A) com efeito fixo de borough × mês no lugar do de mês;
  (D) estudo de eventos: ExpTáxi_z × 1[mês = m], com referência em nov/2022 (Figura 9).

Saídas: resultados/taxi.json e figuras/fig_estudo_eventos_taxi.png
"""
import json
from datetime import datetime

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import requests

from config import EXPOSICAO, EXPOSICAO_TAXI, FIGURAS, PAINEL, RESULTADOS, ZONAS, conectar
from estimador import erros_padrao, estimar, resumo, t_critico

con = conectar()

# --- Exposição ao táxi por zona em 2021 (calculada só se ainda não existir)
if not EXPOSICAO_TAXI.exists():
    con.execute("CREATE TABLE contagem (zona BIGINT, n BIGINT)")
    temporario = EXPOSICAO_TAXI.with_suffix(".tmp.parquet")
    for tipo in ("yellow", "green"):
        for mes in range(1, 13):
            url = f"https://d37ci6vzurychx.cloudfront.net/trip-data/{tipo}_tripdata_2021-{mes:02d}.parquet"
            temporario.write_bytes(requests.get(url, timeout=300).content)
            con.execute(f"""
                INSERT INTO contagem SELECT PULocationID, count(*) FROM read_parquet('{temporario}')
                WHERE PULocationID BETWEEN 1 AND 263 AND trip_distance > 0 AND fare_amount > 0 GROUP BY 1
            """)
            temporario.unlink()
    con.execute(f"""
        COPY (SELECT e.zona, coalesce(t.n, 0) AS taxi_2021, e.n_viagens_base AS uber_lyft_2021,
                     coalesce(t.n, 0) / (coalesce(t.n, 0) + e.n_viagens_base) AS exposicao_taxi
              FROM read_csv_auto('{EXPOSICAO}') e
              LEFT JOIN (SELECT zona, sum(n) AS n FROM contagem GROUP BY zona) t USING (zona)
              ORDER BY e.zona) TO '{EXPOSICAO_TAXI}' (HEADER)
    """)

# --- Painel com a exposição ao táxi (et) e o identificador borough × mês
con.execute(f"""
    CREATE VIEW p AS
    SELECT p.*, t.exposicao_taxi AS et, z."Borough" || '_' || strftime(p.mes, '%Y-%m') AS borough_mes
    FROM read_parquet('{PAINEL}') p
    JOIN read_csv_auto('{EXPOSICAO_TAXI}') t USING (zona)
    JOIN read_csv_auto('{ZONAS}') z ON p.zona = z."LocationID"
""")
p10, p50, p90, dp = con.execute(
    "SELECT approx_quantile(et, 0.1), approx_quantile(et, 0.5), approx_quantile(et, 0.9), stddev_samp(et) FROM p"
).fetchone()
saida = {"exposicao_taxi_entre_viagens": {"p10": p10, "p50": p50, "p90": p90, "dp": dp}}

DID = {"pos": "et * CAST(mes >= DATE '2023-01-01' AS INTEGER)",
       "dez22": "et * CAST(mes = DATE '2022-12-01' AS INTEGER)"}
EF_BOROUGH_MES = ["zona", "borough_mes", "hora", "dia_semana"]
ESPECS = {
    "A_did": (DID, None),
    "B_did_controle_lyft": ({**DID, "inter": "exposicao_x_competicao"}, None),
    "C_did_borough_mes": (DID, EF_BOROUGH_MES),
}
for nome, (regs, ef) in ESPECS.items():
    kwargs = {"efeitos_fixos": ef, "chaves_extra": ("mes",)} if ef else {}
    saida[nome] = resumo(estimar(con, "p", regs, **kwargs), ["pos"])
    c = saida[nome]["coef"]["pos"]
    print(f"{nome:<22} {c['beta']:.3f}  ep zona {c['ep_zona']:.3f}  ep 2 vias {c['ep_2vias']:.3f}", flush=True)

# --- (D) Estudo de eventos: um coeficiente por mês, referência nov/2022.
# Erros-padrão clusterizados por zona (com um regressor por mês, a correção em duas vias
# não é informativa).
meses = [m for (m,) in con.execute("SELECT DISTINCT strftime(mes, '%Y-%m') FROM p ORDER BY 1").fetchall()]
REFERENCIA = "2022-11"
res = estimar(con, "p", {m: f"et * CAST(mes = DATE '{m}-01' AS INTEGER)" for m in meses if m != REFERENCIA})
ep, g = erros_padrao(res)
serie = [{"mes": m, "beta": res["beta"].get(m, 0.0), "ep_zona": ep.get(m, 0.0)} for m in meses]
saida["D_estudo_eventos"] = {"referencia": REFERENCIA, "serie": serie}
(RESULTADOS / "taxi.json").write_text(json.dumps(saida, indent=2, default=float), encoding="utf-8")

# --- Figura 9
t95 = t_critico(g - 1)
x = [datetime.strptime(s["mes"], "%Y-%m") for s in serie]
b = np.array([s["beta"] for s in serie])
e = np.array([s["ep_zona"] for s in serie])
plt.rcParams.update({"font.family": "serif", "font.size": 10, "axes.grid": True, "grid.color": "#dddddd"})
fig, ax = plt.subplots(figsize=(6.3, 3.4))
ax.axhline(0, color="#444444", linewidth=0.8)
ax.axvline(datetime(2022, 12, 19), color="#c1541f", linestyle="--", linewidth=1.2, label="Reajuste do táxi (19/12/2022)")
ax.fill_between(x, b - t95 * e, b + t95 * e, color="#2a78d6", alpha=0.18, linewidth=0, label="IC 95% (EP clusterizado por zona)")
ax.plot(x, b, color="#2a78d6", marker="o", markersize=3, linewidth=1.3, label="Coeficiente estimado")
ax.set_ylabel("Efeito sobre log(preço por milha)\n(por unidade de exposição ao táxi)")
ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=(1, 7)))
ax.xaxis.set_major_formatter(mdates.DateFormatter("%m/%Y"))
ax.spines[["top", "right"]].set_visible(False)
ax.legend(frameon=False, fontsize=8, loc="upper left")
fig.tight_layout()
fig.savefig(FIGURAS / "fig_estudo_eventos_taxi.png", dpi=300, bbox_inches="tight")
