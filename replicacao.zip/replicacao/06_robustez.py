"""
Passo 6 — Testes de robustez que usam apenas o painel (Tabelas 4, 5, 7, 8 e 9).

Tabela 4: (2) sem efeitos fixos de hora e dia da semana; (3) erros-padrão clusterizados
          por mês; (4) preço por milha em nível. A coluna (5), que exige os dados de 2021,
          está no passo 7.
Tabela 5: (6) erros-padrão em duas vias (zona e mês); (7) sem as zonas com menos de
          10 mil viagens; (8) só Manhattan; (9) só os demais boroughs.
Tabela 7: estimação separada para 2022-2023 e 2024, todas as zonas e só Manhattan.
Tabela 8: (18) efeito fixo de zona × mês do ano no lugar do de zona; (19) efeito fixo
          de borough × mês no lugar do de mês.
Tabela 9: estimação separada para cada ano (2022, 2023, 2024) e região (todas as zonas,
          Manhattan e demais zonas).

A coluna (1) das Tabelas 4 e 8 repete a especificação principal (Tabela 3, coluna 1).
Saída: resultados/robustez.json
"""
import json

from config import EFEITOS_FIXOS, PAINEL, RESULTADOS, ZONAS, conectar
from estimador import erros_padrao, erros_padrao_2vias, estimar, p_valor

con = conectar()
INTERACAO = {"inter": "exposicao_x_competicao"}

# Painel com o borough de cada zona e os identificadores dos efeitos fixos alternativos.
con.execute(f"""
    CREATE VIEW p AS
    SELECT p.*, z."Borough" AS borough,
           p.zona * 100 + month(p.mes) AS zona_mes_do_ano,
           z."Borough" || '_' || strftime(p.mes, '%Y-%m') AS borough_mes
    FROM read_parquet('{PAINEL}') p JOIN read_csv_auto('{ZONAS}') z ON p.zona = z."LocationID"
""")


def rodar(nome, tabela="p", efeitos_fixos=EFEITOS_FIXOS, y="log_price_per_mile", cluster="zona"):
    """Estima a interação e devolve β, erro-padrão, p-valor, N e número de clusters."""
    res = estimar(con, tabela, INTERACAO, efeitos_fixos=efeitos_fixos, y=y, chaves_extra=("zona", "mes"))
    if cluster == "2vias":
        ep, g = erros_padrao_2vias(res)
    else:
        ep, g = erros_padrao(res, (cluster,))
    b, se = res["beta"]["inter"], ep["inter"]
    saida = {"beta": b, "ep": se, "p": p_valor(b / se, g - 1), "n_obs": res["n_obs"], "clusters": g}
    print(f"{nome:<32} β = {b:8.3f}  ep {se:.3f}  p {saida['p']:.3f}  N {res['n_obs']:,}", flush=True)
    return saida


resultados = {}

# --- Tabelas 4 e 5
resultados["t4_c2_sem_ef_hora_dia"] = rodar("sem EF de hora e dia", efeitos_fixos=["zona", "mes"])
resultados["t4_c3_cluster_mes"] = rodar("cluster por mês", cluster="mes")
resultados["t4_c4_preco_em_nivel"] = rodar("preço por milha em nível", y="price_per_mile")
resultados["t5_c6_cluster_2vias"] = rodar("cluster em duas vias", cluster="2vias")

baixo_volume = [z for (z,) in con.execute("SELECT zona FROM p GROUP BY zona HAVING count(*) < 10000 ORDER BY zona").fetchall()]
con.execute(f"CREATE VIEW p_volume AS SELECT * FROM p WHERE zona NOT IN ({','.join(map(str, baixo_volume))})")
resultados["t5_c7_sem_baixo_volume"] = {**rodar("sem zonas de baixo volume", "p_volume"), "zonas_excluidas": baixo_volume}

con.execute("CREATE VIEW p_manhattan AS SELECT * FROM p WHERE borough = 'Manhattan'")
con.execute("CREATE VIEW p_demais AS SELECT * FROM p WHERE borough IN ('Brooklyn', 'Queens', 'Bronx', 'Staten Island')")
resultados["t5_c8_manhattan"] = rodar("só Manhattan", "p_manhattan")
resultados["t5_c9_demais_boroughs"] = rodar("só demais boroughs", "p_demais")

# --- Tabela 7: subperíodos
for periodo, filtro_periodo in {"2022_2023": "year(mes) <= 2023", "2024": "year(mes) = 2024"}.items():
    for regiao, filtro_regiao in {"todas": "TRUE", "manhattan": "borough = 'Manhattan'"}.items():
        nome = f"t7_{periodo}_{regiao}"
        con.execute(f"CREATE VIEW {nome} AS SELECT * FROM p WHERE {filtro_periodo} AND {filtro_regiao}")
        resultados[nome] = rodar(nome, nome)

# --- Tabela 8: sazonalidade própria de cada zona e choques por borough
resultados["t8_c18_zona_mes_do_ano"] = rodar("EF zona × mês do ano", efeitos_fixos=["zona_mes_do_ano", "mes", "hora", "dia_semana"])
resultados["t8_c19_borough_mes"] = rodar("EF borough × mês", efeitos_fixos=["zona", "borough_mes", "hora", "dia_semana"])

# --- Tabela 9: ano a ano, por região
REGIOES = {"todas": "TRUE", "manhattan": "borough = 'Manhattan'", "demais": "borough <> 'Manhattan'"}
for ano in (2022, 2023, 2024):
    for regiao, filtro in REGIOES.items():
        nome = f"t9_{ano}_{regiao}"
        con.execute(f"CREATE VIEW {nome} AS SELECT * FROM p WHERE year(mes) = {ano} AND {filtro}")
        resultados[nome] = rodar(nome, nome)

(RESULTADOS / "robustez.json").write_text(json.dumps(resultados, indent=2, default=float), encoding="utf-8")
