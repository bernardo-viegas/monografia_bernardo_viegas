"""
Passo 2 — Constrói as variáveis de competição e o painel usado nas regressões.

Modelo (equação 1 do trabalho):
    ln(P_izt) = β·(Exposição_z × Competição_t) + θ1·ln(D_izt) + θ2·ln(T_izt)
                + EF hora + EF dia da semana + EF zona + EF mês + erro
    i = viagem, z = zona de embarque, t = mês.

Saídas (na pasta de dados):
    competicao_mensal.csv  Competição_t: participação da Lyft no total de viagens Uber + Lyft, por mês.
    exposicao_zona.csv     Exposição_z: participação da Lyft nas viagens iniciadas na zona em 2021.
    painel_regressao_uber_lyft.parquet  viagens da Uber de jan/2022 a dez/2024, sem valores extremos.
    metadados_painel.json  limites do corte de valores extremos e número de viagens antes e depois dele.
"""
import json

from config import (AMOSTRA_FIM, AMOSTRA_INICIO, BASE_FIM, BASE_INICIO, COMPETICAO, EXPOSICAO,
                    LYFT, METADADOS, PAINEL, PASTA_BRUTA, UBER, conectar)

con = conectar()

# Viagens válidas da Uber e da Lyft: distância, duração e tarifa positivas e zona de
# embarque entre as 263 zonas da TLC (264 e 265 são "desconhecida").
con.execute(f"""
    CREATE VIEW viagens AS
    SELECT * FROM read_parquet('{PASTA_BRUTA}/*.parquet', union_by_name=true)
    WHERE hvfhs_license_num IN ('{UBER}', '{LYFT}')
      AND trip_miles > 0 AND trip_time > 0 AND base_passenger_fare > 0
      AND PULocationID BETWEEN 1 AND 263
""")

# Competição_t: participação mensal da Lyft na cidade (todos os meses de 2021 a 2024;
# os de 2021 servem para calcular as antecipações e defasagens).
con.execute(f"""
    CREATE TABLE competicao AS
    SELECT date_trunc('month', pickup_datetime)::DATE AS mes,
           avg(CASE WHEN hvfhs_license_num = '{LYFT}' THEN 1.0 ELSE 0.0 END) AS competicao_t,
           count(*) AS n_viagens_mes
    FROM viagens GROUP BY 1 ORDER BY 1
""")

# Exposição_z: participação da Lyft nas viagens iniciadas em cada zona no período-base (2021).
con.execute(f"""
    CREATE TABLE exposicao AS
    SELECT PULocationID AS zona,
           avg(CASE WHEN hvfhs_license_num = '{LYFT}' THEN 1.0 ELSE 0.0 END) AS exposicao_z,
           count(*) AS n_viagens_base
    FROM viagens
    WHERE pickup_datetime >= '{BASE_INICIO}' AND pickup_datetime < '{BASE_FIM}'
    GROUP BY 1
""")

# Viagens da Uber no período da amostra, com o preço por milha (tarifa-base / distância).
con.execute(f"""
    CREATE VIEW uber AS
    SELECT *, base_passenger_fare / trip_miles AS price_per_mile
    FROM viagens
    WHERE hvfhs_license_num = '{UBER}'
      AND pickup_datetime >= '{AMOSTRA_INICIO}' AND pickup_datetime < '{AMOSTRA_FIM}'
      AND PULocationID IN (SELECT zona FROM exposicao)
""")

# Corte de valores extremos: percentis 1 e 99 do preço por milha e da duração.
n_antes, p1, p99, t1, t99, max_preco, max_duracao = con.execute("""
    SELECT count(*), approx_quantile(price_per_mile, 0.01), approx_quantile(price_per_mile, 0.99),
           approx_quantile(trip_time, 0.01), approx_quantile(trip_time, 0.99),
           max(price_per_mile), max(trip_time)
    FROM uber
""").fetchone()
p1, p99, t1, t99 = round(p1, 2), round(p99, 2), int(round(t1)), int(round(t99))

# Painel: uma linha por viagem da Uber, com as variáveis do modelo.
con.execute(f"""
    COPY (
        SELECT u.PULocationID AS zona,
               date_trunc('month', u.pickup_datetime)::DATE AS mes,
               u.trip_miles, u.trip_time, u.price_per_mile,
               ln(u.price_per_mile) AS log_price_per_mile,
               ln(u.trip_miles) AS log_distance,
               ln(u.trip_time) AS log_duration,
               extract(hour FROM u.pickup_datetime) AS hora,
               dayofweek(u.pickup_datetime) AS dia_semana,
               e.exposicao_z, c.competicao_t,
               e.exposicao_z * c.competicao_t AS exposicao_x_competicao
        FROM uber u
        JOIN exposicao e ON u.PULocationID = e.zona
        JOIN competicao c ON date_trunc('month', u.pickup_datetime)::DATE = c.mes
        WHERE u.price_per_mile BETWEEN {p1} AND {p99} AND u.trip_time BETWEEN {t1} AND {t99}
    ) TO '{PAINEL}' (FORMAT PARQUET, COMPRESSION ZSTD)
""")
con.execute(f"COPY competicao TO '{COMPETICAO}' (HEADER)")
con.execute(f"COPY exposicao TO '{EXPOSICAO}' (HEADER)")

n_depois = con.execute(f"SELECT count(*) FROM read_parquet('{PAINEL}')").fetchone()[0]
meta = {"n_antes_corte": n_antes, "n_depois_corte": n_depois, "ppm_p1": p1, "ppm_p99": p99,
        "tt_p1": t1, "tt_p99": t99, "ppm_max_bruto": max_preco, "tt_max_bruto": max_duracao}
METADADOS.write_text(json.dumps(meta, indent=2, default=float), encoding="utf-8")
print(meta)
