"""
Estimador de mínimos quadrados com efeitos fixos de alta dimensão e erros-padrão
clusterizados, para uma base grande demais para caber na memória (480 milhões de viagens).

Ideia central
-------------
Todos os regressores de interesse (Exposição_z × Competição_t e suas variações) são
constantes dentro de uma "célula", definida pela combinação dos efeitos fixos
(zona × mês × hora × dia da semana). Só os controles de viagem (log da distância e
log da duração) e a variável dependente variam dentro da célula. Por isso, a matriz
de produtos cruzados da regressão "demeaned" se decompõe exatamente em duas partes:

  1. a parte DENTRO de cada célula, que depende só de somas e médias por célula
     e é calculada numa única passada pelos dados (DuckDB);
  2. a parte ENTRE células, obtida retirando os efeitos fixos das médias por célula
     por projeções alternadas ponderadas pelo número de viagens.

O resultado é idêntico ao de uma regressão com uma variável binária para cada zona,
mês, hora e dia da semana, mas sem nunca carregar a base viagem a viagem na memória.

Os erros-padrão clusterizados também saem da tabela de células, desde que o cluster
(zona, mês ou ambos) seja constante dentro de cada célula.
"""
import math
import warnings

import numpy as np
import pandas as pd

from config import EFEITOS_FIXOS, Y


# ---------------------------------------------------------------------------
# Estimação
# ---------------------------------------------------------------------------
def _retirar_efeitos_fixos(cel, colunas, efeitos_fixos, tol=1e-10, max_iter=1000):
    """Retira das médias por célula os efeitos fixos, por projeções alternadas
    (Gauss-Seidel) ponderadas pelo número de viagens de cada célula.
    A cada passo, subtrai de cada coluna a sua média ponderada dentro de cada grupo
    de um efeito fixo, até que nenhuma correção passe de `tol`."""
    pesos = cel["n"].to_numpy(float)
    grupos = [pd.factorize(cel[ef])[0] for ef in efeitos_fixos]
    soma_pesos = [np.bincount(g, weights=pesos) for g in grupos]
    resid = {c: cel[c].to_numpy(float).copy() for c in colunas}
    for _ in range(max_iter):
        maior_correcao = 0.0
        for g, sp in zip(grupos, soma_pesos):
            for c in colunas:
                media_grupo = np.bincount(g, weights=pesos * resid[c]) / sp
                resid[c] -= media_grupo[g]
                maior_correcao = max(maior_correcao, np.abs(media_grupo).max())
        if maior_correcao < tol:
            return resid
    warnings.warn(f"projeções alternadas não convergiram em {max_iter} iterações")
    return resid


def estimar(con, tabela, regressores, efeitos_fixos=EFEITOS_FIXOS, y=Y, chaves_extra=(),
            controles=("log_distance", "log_duration")):
    """Estima y ~ regressores + controles + efeitos fixos.

    regressores   : {nome: expressão SQL}, cada uma constante dentro da célula.
    efeitos_fixos : colunas que definem os efeitos fixos (e as células).
    chaves_extra  : colunas acrescentadas à célula sem virar efeito fixo; servem para
                    poder clusterizar por elas (por exemplo, zona, quando o efeito fixo
                    é de zona × ano).
    Retorna um dicionário com os coeficientes, a matriz X'X e os "scores" de cada
    célula, usados no cálculo dos erros-padrão.
    """
    chaves = list(efeitos_fixos) + [c for c in chaves_extra if c not in efeitos_fixos]
    d, u = controles

    # 1) uma passada pelos dados: por célula, número de viagens, médias e somas de produtos
    medias_reg = ", ".join(f"avg({expr}) AS r{i}" for i, expr in enumerate(regressores.values()))
    cel = con.execute(f"""
        SELECT {", ".join(chaves)}, count(*) AS n, {medias_reg},
               avg({d}) AS d_m, avg({u}) AS u_m, avg({y}) AS y_m,
               sum({d}*{d}) AS s_dd, sum({u}*{u}) AS s_uu, sum({y}*{y}) AS s_yy,
               sum({d}*{u}) AS s_du, sum({d}*{y}) AS s_dy, sum({u}*{y}) AS s_uy
        FROM {tabela} GROUP BY {", ".join(chaves)}
    """).fetchdf()
    n = cel["n"].to_numpy(float)

    # 2) parte dentro da célula: variação dos controles e de y em torno da média da célula
    def dentro(a, b):
        return cel[f"s_{a}{b}"].to_numpy() - n * cel[f"{a}_m"].to_numpy() * cel[f"{b}_m"].to_numpy()
    w = {ab: dentro(*ab) for ab in ("dd", "uu", "yy", "du", "dy", "uy")}

    # 3) parte entre células: médias por célula sem os efeitos fixos
    colunas = [f"r{i}" for i in range(len(regressores))] + ["d_m", "u_m", "y_m"]
    resid = _retirar_efeitos_fixos(cel, colunas, efeitos_fixos)
    X = np.column_stack([resid[c] for c in colunas[:-1]])
    yt = resid["y_m"]
    kd, ku = X.shape[1] - 2, X.shape[1] - 1              # posições dos dois controles

    # 4) equações normais: X'X e X'y = parte entre células + parte dentro (só controles)
    XX = X.T @ (X * n[:, None])
    XX[kd, kd] += w["dd"].sum(); XX[ku, ku] += w["uu"].sum()
    XX[kd, ku] += w["du"].sum(); XX[ku, kd] += w["du"].sum()
    Xy = X.T @ (n * yt)
    Xy[kd] += w["dy"].sum(); Xy[ku] += w["uy"].sum()
    yy = (n * yt * yt).sum() + w["yy"].sum()
    beta = np.linalg.solve(XX, Xy)

    # 5) score de cada célula (soma de x̃·û sobre as viagens da célula), para os erros-padrão
    S = X * (n * (yt - X @ beta))[:, None]
    S[:, kd] += w["dy"] - beta[kd] * w["dd"] - beta[ku] * w["du"]
    S[:, ku] += w["uy"] - beta[kd] * w["du"] - beta[ku] * w["uu"]

    nomes = list(regressores) + list(controles)
    return {"nomes": nomes, "beta": dict(zip(nomes, beta)), "beta_vetor": beta, "XX": XX,
            "n_obs": int(n.sum()), "r2_dentro": float(1 - (yy - beta @ Xy) / yy),
            "celulas": cel[chaves], "scores": S}


# ---------------------------------------------------------------------------
# Erros-padrão
# ---------------------------------------------------------------------------
def variancia_cluster(res, cluster):
    """Matriz de variância clusterizada (CR1, com o ajuste para amostras pequenas usual)
    pelos grupos definidos pelas colunas em `cluster`. Retorna (V, número de clusters)."""
    codigos = pd.factorize(res["celulas"][list(cluster)].astype(str).agg("|".join, axis=1))[0]
    G = codigos.max() + 1
    S = np.zeros((G, res["scores"].shape[1]))
    np.add.at(S, codigos, res["scores"])                   # soma dos scores por cluster
    inv = np.linalg.inv(res["XX"])
    N, K = res["n_obs"], S.shape[1]
    return inv @ (S.T @ S) @ inv * (G / (G - 1)) * ((N - 1) / (N - K)), int(G)


def erros_padrao(res, cluster=("zona",)):
    """Erros-padrão clusterizados em uma via. Retorna ({nome: ep}, número de clusters)."""
    V, G = variancia_cluster(res, cluster)
    return dict(zip(res["nomes"], np.sqrt(np.diag(V)))), G


def erros_padrao_2vias(res, c1="zona", c2="mes"):
    """Erros-padrão clusterizados em duas vias (Cameron, Gelbach e Miller, 2011):
    V = V(zona) + V(mês) − V(zona × mês). Se a variância resultar negativa, usa-se o
    maior dos erros-padrão de uma via, como sugerem os autores. Retorna também o
    menor número de clusters, usado como base para os graus de liberdade."""
    V1, g1 = variancia_cluster(res, (c1,))
    V2, g2 = variancia_cluster(res, (c2,))
    V12, _ = variancia_cluster(res, (c1, c2))
    var = np.diag(V1 + V2 - V12).copy()
    negativa = var < 0
    var[negativa] = np.maximum(np.diag(V1), np.diag(V2))[negativa]
    return dict(zip(res["nomes"], np.sqrt(var))), min(g1, g2)


def teste_conjunto(res, nomes, duas_vias=False):
    """Teste de Wald de que dois coeficientes são ambos zero, com variância clusterizada
    por zona (ou em duas vias, por zona e mês). Retorna a estatística e o p-valor
    (qui-quadrado com 2 graus de liberdade). Em duas vias, a submatriz de variância
    pode não ser positiva definida; nesse caso o teste não é calculado (retorna None)."""
    assert len(nomes) == 2, "o p-valor abaixo vale para exatamente dois coeficientes"
    V = variancia_cluster(res, ("zona",))[0]
    if duas_vias:
        V = V + variancia_cluster(res, ("mes",))[0] - variancia_cluster(res, ("zona", "mes"))[0]
    i = [res["nomes"].index(nm) for nm in nomes]
    Vi = V[np.ix_(i, i)]
    if np.any(np.linalg.eigvalsh(Vi) <= 0):
        return None
    b = res["beta_vetor"][i]
    W = float(b @ np.linalg.inv(Vi) @ b)
    return {"wald": W, "p": math.exp(-W / 2)}


def resumo(res, nomes=None):
    """Coeficientes com erros-padrão e p-valores por zona e em duas vias (zona e mês)."""
    ep_z, g_z = erros_padrao(res)
    ep_2, g_2 = erros_padrao_2vias(res)
    saida = {"n_obs": res["n_obs"], "r2_dentro": res["r2_dentro"], "clusters_zona": g_z, "coef": {}}
    for nm in nomes or res["nomes"]:
        b = res["beta"][nm]
        saida["coef"][nm] = {"beta": b, "ep_zona": ep_z[nm], "p_zona": p_valor(b / ep_z[nm], g_z - 1),
                             "ep_2vias": ep_2[nm], "p_2vias": p_valor(b / ep_2[nm], g_2 - 1)}
    return saida


# ---------------------------------------------------------------------------
# Distribuição t de Student (p-valores e valores críticos), sem depender do scipy.
# Usa a função beta incompleta regularizada (Numerical Recipes, fração contínua de Lentz).
# Graus de liberdade = número de clusters − 1.
# ---------------------------------------------------------------------------
def _beta_incompleta(a, b, x):
    if x <= 0 or x >= 1:
        return float(x >= 1)
    if x > (a + 1) / (a + b + 2):                          # simetria: converge mais rápido
        return 1 - _beta_incompleta(b, a, 1 - x)
    ln_frente = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1 - x)
    minimo = 1e-300
    c, d = 1.0, 1 - (a + b) * x / (a + 1)
    d = 1 / (d if abs(d) > minimo else minimo)
    h = d
    for m in range(1, 300):
        for num in (m * (b - m) * x / ((a + 2 * m - 1) * (a + 2 * m)),
                    -(a + m) * (a + b + m) * x / ((a + 2 * m) * (a + 2 * m + 1))):
            d = 1 + num * d
            d = 1 / (d if abs(d) > minimo else minimo)
            c = 1 + num / c
            c = c if abs(c) > minimo else minimo
            h *= d * c
        if abs(d * c - 1) < 1e-14:
            break
    return math.exp(ln_frente) * h / a


def p_valor(t, gl):
    """p-valor bicaudal da estatística t com `gl` graus de liberdade."""
    return _beta_incompleta(gl / 2, 0.5, gl / (gl + t * t))


def t_critico(gl, alfa=0.05):
    """Valor crítico bicaudal da distribuição t (por bisseção)."""
    baixo, alto = 0.0, 100.0
    while alto - baixo > 1e-10:
        meio = (baixo + alto) / 2
        baixo, alto = (meio, alto) if p_valor(meio, gl) > alfa else (baixo, meio)
    return alto
