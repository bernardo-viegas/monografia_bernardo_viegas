"""
Passo 7 — Testes de robustez que precisam dos dados brutos do passo 1.

Tabela 4, coluna (5) — mesmo desenho num período anterior à amostra:
    Exposição_z recalculada com jan-jun/2021 e modelo estimado em jul-dez/2021, com a
    participação mensal da Lyft desses meses e o mesmo corte de valores extremos do painel.
Tabela 6 — sensibilidade ao corte de valores extremos:
    (10) sem nenhum corte; (12) corte nos percentis 5 e 95 (a coluna 11, percentis 1 e 99,
    é a especificação principal).

Saída: resultados/robustez_dados_brutos.json
"""
import json

from config import (AMOSTRA_FIM, AMOSTRA_INICIO, COMPETICAO, EXPOSICAO, LYFT, METADADOS,
                    PASTA_BRUTA, RESULTADOS, UBER, conectar)
from estimador import erros_padrao, estimar, p_valor

con = conectar()
corte = json.loads(METADADOS.read_text(encoding="utf-8"))   # percentis 1 e 99 do painel principal


def rodar(nome, tabela):
    """Especificação principal (efeitos fixos de zona, mês, hora e dia; cluster por zona)."""
    res = estimar(con, tabela, {"inter": "exposicao_x_competicao"})
    ep, g = erros_padrao(res)
    b, se = res["beta"]["inter"], ep["inter"]
    print(f"{nome:<22} β = {b:8.3f}  ep {se:.3f}  N {res['n_obs']:,}", flush=True)
    return {"beta": b, "ep": se, "p": p_valor(b / se, g - 1), "n_obs": res["n_obs"], "clusters": g}


# Viagens válidas da Uber e da Lyft, com as variáveis do modelo calculadas viagem a viagem.
con.execute(f"""
    CREATE VIEW viagens AS
    SELECT hvfhs_license_num AS empresa, pickup_datetime, PULocationID AS zona, trip_time,
           date_trunc('month', pickup_datetime)::DATE AS mes,
           base_passenger_fare / trip_miles AS price_per_mile,
           ln(base_passenger_fare / trip_miles) AS log_price_per_mile,
           ln(trip_miles) AS log_distance, ln(trip_time) AS log_duration,
           extract(hour FROM pickup_datetime) AS hora, dayofweek(pickup_datetime) AS dia_semana
    FROM read_parquet('{PASTA_BRUTA}/*.parquet', union_by_name=true)
    WHERE hvfhs_license_num IN ('{UBER}', '{LYFT}')
      AND trip_miles > 0 AND trip_time > 0 AND base_passenger_fare > 0
      AND PULocationID BETWEEN 1 AND 263
""")
resultados = {}

# --- Tabela 4, coluna (5): exposição em jan-jun/2021, regressão em jul-dez/2021.
con.execute(f"""
    CREATE TABLE exp_1sem AS
    SELECT zona, avg(CASE WHEN empresa = '{LYFT}' THEN 1.0 ELSE 0.0 END) AS exposicao_z
    FROM viagens WHERE pickup_datetime >= '2021-01-01' AND pickup_datetime < '2021-07-01' GROUP BY zona
""")
con.execute(f"""
    CREATE VIEW periodo_anterior AS
    SELECT v.*, e.exposicao_z * c.competicao_t AS exposicao_x_competicao
    FROM viagens v
    JOIN exp_1sem e USING (zona)
    JOIN read_csv_auto('{COMPETICAO}') c ON v.mes = c.mes::DATE
    WHERE v.empresa = '{UBER}' AND v.pickup_datetime >= '2021-07-01' AND v.pickup_datetime < '2022-01-01'
      AND v.price_per_mile BETWEEN {corte['ppm_p1']} AND {corte['ppm_p99']}
      AND v.trip_time BETWEEN {corte['tt_p1']} AND {corte['tt_p99']}
""")
resultados["t4_c5_periodo_anterior"] = rodar("período anterior (2021)", "periodo_anterior")

# --- Tabela 6: viagens da Uber no período da amostra, sem corte de valores extremos.
con.execute(f"""
    CREATE VIEW sem_corte AS
    SELECT v.*, e.exposicao_z * c.competicao_t AS exposicao_x_competicao
    FROM viagens v
    JOIN read_csv_auto('{EXPOSICAO}') e USING (zona)
    JOIN read_csv_auto('{COMPETICAO}') c ON v.mes = c.mes::DATE
    WHERE v.empresa = '{UBER}' AND v.pickup_datetime >= '{AMOSTRA_INICIO}' AND v.pickup_datetime < '{AMOSTRA_FIM}'
""")
resultados["t6_c10_sem_corte"] = rodar("sem corte", "sem_corte")

p5, p95, t5, t95 = con.execute("""
    SELECT approx_quantile(price_per_mile, 0.05), approx_quantile(price_per_mile, 0.95),
           approx_quantile(trip_time, 0.05), approx_quantile(trip_time, 0.95) FROM sem_corte
""").fetchone()
con.execute(f"""
    CREATE VIEW corte_p5_p95 AS SELECT * FROM sem_corte
    WHERE price_per_mile BETWEEN {round(p5, 2)} AND {round(p95, 2)}
      AND trip_time BETWEEN {round(t5)} AND {round(t95)}
""")
resultados["t6_c12_corte_p5_p95"] = rodar("corte P5-P95", "corte_p5_p95")

(RESULTADOS / "robustez_dados_brutos.json").write_text(json.dumps(resultados, indent=2, default=float), encoding="utf-8")
