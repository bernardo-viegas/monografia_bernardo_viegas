"""
Passo 3 — Estatísticas descritivas das variáveis do modelo (Tabela 2).

Média, desvio-padrão, mínimo, máximo e N, calculados sobre as viagens do painel.
A duração e seu logaritmo são apresentados em minutos, como na Tabela 2; nas regressões,
o log da duração está em segundos, o que só desloca a média por uma constante (ln 60) e
não altera nenhum coeficiente. A última linha traz a exposição calculada por
zona (uma observação por zona, sem ponderar pelo número de viagens).
Saída: resultados/tabela2_descritivas.json
"""
import json

import pandas as pd

from config import EXPOSICAO, PAINEL, RESULTADOS, conectar

VARIAVEIS = {
    "Preço por milha": "price_per_mile",
    "Log do preço por milha": "log_price_per_mile",
    "Distância (milhas)": "trip_miles",
    "Log da distância": "log_distance",
    "Duração (minutos)": "trip_time / 60",
    "Log da duração": "ln(trip_time / 60)",
    "Exposição_z": "exposicao_z",
    "Competição_t": "competicao_t",
    "Exposição_z × Competição_t": "exposicao_x_competicao",
}

con = conectar()
linhas = []
for rotulo, expr in VARIAVEIS.items():
    media, dp, minimo, maximo, n = con.execute(
        f"SELECT avg({expr}), stddev_pop({expr}), min({expr}), max({expr}), count(*) "
        f"FROM read_parquet('{PAINEL}')").fetchone()
    linhas.append({"variavel": rotulo, "media": media, "dp": dp, "min": minimo, "max": maximo, "n": n})

# Exposição_z com uma observação por zona, restrita às zonas presentes no painel.
zonas_painel = con.execute(f"SELECT DISTINCT zona FROM read_parquet('{PAINEL}')").fetchdf()["zona"]
exp = pd.read_csv(EXPOSICAO).query("zona in @zonas_painel")["exposicao_z"]
linhas.append({"variavel": "Exposição_z (por zona)", "media": exp.mean(), "dp": exp.std(),
               "min": exp.min(), "max": exp.max(), "n": len(exp)})

for linha in linhas:
    print(f"{linha['variavel']:<28} média {linha['media']:9.3f}  dp {linha['dp']:7.3f}  "
          f"mín {linha['min']:8.3f}  máx {linha['max']:9.3f}  N {linha['n']:,}")
(RESULTADOS / "tabela2_descritivas.json").write_text(json.dumps(linhas, indent=2, default=float), encoding="utf-8")
