"""
Passo 4 — Resultados principais (Tabela 3).

  (1) especificação principal, equação (1);
  (2) + Exposição_z × tempo (anos desde jan/2022): tendência linear própria das zonas expostas;
  (3) efeito fixo de zona × ano no lugar do de zona;
  (4) a (6): teste de falsificação (antecipações) aplicado a (1), (2) e (3): acrescenta
      Exposição_z × Competição_{t+1} e Exposição_z × Competição_{t+2}. Como a competição
      futura não pode afetar o preço de hoje, esses coeficientes deveriam ser zero.
      Exige encerrar a amostra em out/2024, último mês com dois meses à frente.

Erros-padrão clusterizados por zona e em duas vias (zona e mês).
Saída: resultados/tabela3.json
"""
import json

from config import COMPETICAO, EFEITOS_FIXOS, PAINEL, RESULTADOS, conectar
from estimador import estimar, resumo, teste_conjunto

con = conectar()

# Competição dos dois meses seguintes, a partir da série mensal da participação da Lyft.
con.execute(f"""
    CREATE TABLE comp AS
    SELECT mes::DATE AS mes,
           lead(competicao_t, 1) OVER (ORDER BY mes) AS c_mais1,
           lead(competicao_t, 2) OVER (ORDER BY mes) AS c_mais2
    FROM read_csv_auto('{COMPETICAO}')
""")
# Painel com as variáveis auxiliares: tempo em anos e identificador zona × ano.
con.execute(f"""
    CREATE VIEW p AS
    SELECT p.*, c.c_mais1, c.c_mais2,
           date_diff('month', DATE '2022-01-01', p.mes) / 12.0 AS anos,
           p.zona * 10000 + year(p.mes) AS zona_ano
    FROM read_parquet('{PAINEL}') p JOIN comp c USING (mes)
""")
con.execute("CREATE VIEW p_ate_out2024 AS SELECT * FROM p WHERE mes <= DATE '2024-10-01'")

INTERACAO = {"inter": "exposicao_x_competicao"}
TENDENCIA = {"tend": "exposicao_z * anos"}
ANTECIPACOES = {"mais1": "exposicao_z * c_mais1", "mais2": "exposicao_z * c_mais2"}
EF_ZONA_ANO = ["zona_ano", "mes", "hora", "dia_semana"]

# nome: (tabela, efeitos fixos, regressores)
COLUNAS = {
    "c1_principal": ("p", EFEITOS_FIXOS, INTERACAO),
    "c2_tendencia": ("p", EFEITOS_FIXOS, {**INTERACAO, **TENDENCIA}),
    "c3_zona_ano": ("p", EF_ZONA_ANO, INTERACAO),
    "c4_antecipacoes": ("p_ate_out2024", EFEITOS_FIXOS, {**INTERACAO, **ANTECIPACOES}),
    "c5_antecipacoes_tendencia": ("p_ate_out2024", EFEITOS_FIXOS, {**INTERACAO, **TENDENCIA, **ANTECIPACOES}),
    "c6_antecipacoes_zona_ano": ("p_ate_out2024", EF_ZONA_ANO, {**INTERACAO, **ANTECIPACOES}),
}

saida = {}
for nome, (tabela, ef, regs) in COLUNAS.items():
    # "zona" entra como chave extra da célula para permitir clusterizar por zona
    # quando o efeito fixo é de zona × ano.
    res = estimar(con, tabela, regs, efeitos_fixos=ef, chaves_extra=("zona",))
    saida[nome] = resumo(res)
    if "mais1" in regs:
        saida[nome]["teste_antecipacoes_zona"] = teste_conjunto(res, ["mais1", "mais2"])
        saida[nome]["teste_antecipacoes_2vias"] = teste_conjunto(res, ["mais1", "mais2"], duas_vias=True)
    b = saida[nome]["coef"]["inter"]
    print(f"{nome:<27} β = {b['beta']:7.3f}  ep zona {b['ep_zona']:.3f}  ep 2 vias {b['ep_2vias']:.3f}", flush=True)

(RESULTADOS / "tabela3.json").write_text(json.dumps(saida, indent=2, default=float), encoding="utf-8")
